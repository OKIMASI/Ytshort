"""
Local web app: paste a YouTube link, get back short vertical clips.

Run with:
    python app.py
Then open http://localhost:5000
"""

import os
import threading
import uuid

from flask import Flask, render_template, request, jsonify

from pipeline import run_pipeline

app = Flask(__name__)

# In-memory job store (fine for local single-user use)
JOBS: dict[str, dict] = {}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/start", methods=["POST"])
def start():
    data = request.get_json()
    url = (data.get("url") or "").strip()
    api_key = (data.get("api_key") or os.environ.get("ANTHROPIC_API_KEY") or "").strip()
    max_clips = int(data.get("max_clips") or 5)

    if not url:
        return jsonify({"error": "Paste a YouTube link first."}), 400
    if not api_key:
        return jsonify({"error": "No Anthropic API key found. Set ANTHROPIC_API_KEY or paste one in."}), 400

    job_id = uuid.uuid4().hex[:8]
    JOBS[job_id] = {"status": "running", "log": [], "clips": []}

    def progress_cb(msg):
        JOBS[job_id]["log"].append(msg)

    def worker():
        try:
            clips = run_pipeline(url, api_key, max_clips, progress_cb=progress_cb)
            JOBS[job_id]["clips"] = [
                {
                    "title": c.title,
                    "reason": c.reason,
                    "start": c.start,
                    "end": c.end,
                    "url": f"/static/clips/{os.path.basename(c.path)}",
                }
                for c in clips
            ]
            JOBS[job_id]["status"] = "done"
        except Exception as e:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["log"].append(f"Error: {e}")

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "unknown job"}), 404
    return jsonify(job)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
