# YouTube → Shorts Maker

Paste a YouTube link, get back short vertical clips with captions, picked
automatically by Claude.

## Deploy on your phone (Render, free tier)

1. **Get the code onto GitHub**
   - On github.com (works fine in your phone browser), create a new repository.
   - Upload every file in this folder, keeping the same structure
     (`app.py`, `pipeline.py`, `requirements.txt`, `Dockerfile`,
     `templates/index.html`).

2. **Get an Anthropic API key**
   - console.anthropic.com → Settings → API Keys → Create Key.

3. **Deploy on Render**
   - render.com → sign up (can use your GitHub login) → "New +" → "Web Service"
   - Connect the repo you just created.
   - Render will detect the `Dockerfile` automatically — leave build settings default.
   - Under "Environment", add a variable:
     - Key: `ANTHROPIC_API_KEY`
     - Value: (the key from step 2)
   - Click "Create Web Service". First deploy takes a few minutes (it's
     installing ffmpeg and downloading the Whisper model on first run).

4. **Use it**
   - Render gives you a URL like `https://your-app.onrender.com`.
   - Open that in your phone's browser. That's your paste-the-link page.

## Notes / limits

- Render's **free tier** has limited CPU and RAM, and spins the app down when
  idle (the first request after inactivity takes ~30-60s to wake up). Whisper
  transcription of a long video can be slow on the free tier — for videos
  over ~15-20 minutes, expect it to take several minutes. If that's too slow,
  Render's cheapest paid tier ($7/mo) is noticeably faster.
- The `faster-whisper` model downloads the first time the app runs (a few
  hundred MB) — this happens automatically, just makes the very first job slower.
- This is for personal use. Re-uploading other people's YouTube content
  publicly can run into copyright/ToS issues — keep that in mind depending on
  what you plan to do with the clips.
- To make clips longer/shorter or change how many get generated per video,
  edit the prompt in `pipeline.py` (`find_highlights` function) or the
  `max_clips` field in the UI.
