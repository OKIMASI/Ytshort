"""
Core pipeline for turning a YouTube link into short-form vertical clips.

Steps:
1. Download the source video with yt-dlp
2. Transcribe it with faster-whisper (word-level timestamps)
3. Ask Claude to pick the best short, self-contained moments
4. Cut each moment out with ffmpeg, reframe to 9:16, burn in captions
"""

import os
import re
import json
import subprocess
import uuid
from dataclasses import dataclass, field

import yt_dlp
from faster_whisper import WhisperModel
import anthropic

WORK_DIR = os.path.join(os.path.dirname(__file__), "work")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "static", "clips")
os.makedirs(WORK_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


@dataclass
class Word:
    start: float
    end: float
    text: str


@dataclass
class Clip:
    start: float
    end: float
    title: str
    reason: str
    path: str = ""


def download_video(url: str, job_id: str) -> str:
    """Download a YouTube video and return the local file path."""
    out_path = os.path.join(WORK_DIR, f"{job_id}_source.mp4")
    ydl_opts = {
        "format": "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "outtmpl": out_path,
        "merge_output_format": "mp4",
        "quiet": True,
        "noplaylist": True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    return out_path


def transcribe(video_path: str, model_size: str = "small") -> list[Word]:
    """Transcribe audio with word-level timestamps using faster-whisper."""
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(video_path, word_timestamps=True)

    words: list[Word] = []
    for seg in segments:
        if seg.words:
            for w in seg.words:
                words.append(Word(start=w.start, end=w.end, text=w.word.strip()))
    return words


def words_to_transcript_text(words: list[Word]) -> str:
    """Render a timestamped transcript string for the LLM prompt."""
    lines = []
    bucket_start = None
    bucket_words = []
    for w in words:
        if bucket_start is None:
            bucket_start = w.start
        bucket_words.append(w.text)
        if w.end - bucket_start > 8:  # flush every ~8s
            lines.append(f"[{bucket_start:.1f}] {' '.join(bucket_words)}")
            bucket_start = None
            bucket_words = []
    if bucket_words:
        lines.append(f"[{bucket_start:.1f}] {' '.join(bucket_words)}")
    return "\n".join(lines)


def find_highlights(words: list[Word], api_key: str, max_clips: int = 5) -> list[Clip]:
    """Ask Claude to pick the best short, self-contained clips."""
    transcript_text = words_to_transcript_text(words)
    client = anthropic.Anthropic(api_key=api_key)

    prompt = f"""You are an expert short-form video editor who finds viral-worthy
moments in long videos for TikTok/Reels/Shorts.

Below is a timestamped transcript (timestamps in seconds). Pick up to
{max_clips} moments that would work as standalone vertical short-form clips.
Each clip should be 20-75 seconds long, self-contained (makes sense without
the rest of the video), and have a strong hook in the first 2 seconds
(a bold claim, a question, a punchline, a surprising fact, an emotional beat).

Avoid moments that require earlier context to understand. Prefer moments with
a clear beginning, middle, and payoff.

Respond with ONLY a JSON array, no other text, in this exact format:
[
  {{"start": 123.4, "end": 178.9, "title": "short catchy title", "reason": "why this hooks viewers"}}
]

Transcript:
{transcript_text}
"""

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = "".join(block.text for block in response.content if hasattr(block, "text"))
    raw = re.sub(r"^```json|```$", "", raw.strip(), flags=re.MULTILINE).strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\[.*\]", raw, re.DOTALL)
        data = json.loads(match.group(0)) if match else []

    return [Clip(start=c["start"], end=c["end"], title=c["title"], reason=c["reason"]) for c in data]


def _words_in_range(words: list[Word], start: float, end: float) -> list[Word]:
    return [w for w in words if start <= w.start < end]


def _build_ass_subtitles(words: list[Word], clip_start: float, ass_path: str):
    """Write an .ass subtitle file with word-by-word burned captions."""
    header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Outline, Shadow, Alignment, MarginV
Style: Default,Arial Black,80,&H00FFFFFF,&H00000000,&H00000000,1,4,0,2,120

[Events]
Format: Layer, Start, End, Style, Text
"""

    def fmt_time(t: float) -> str:
        if t < 0:
            t = 0
        h = int(t // 3600)
        m = int((t % 3600) // 60)
        s = t % 60
        return f"{h}:{m:02}:{s:05.2f}"

    lines = [header]
    for w in words:
        s = w.start - clip_start
        e = w.end - clip_start
        if e <= s:
            e = s + 0.3
        lines.append(f"Dialogue: 0,{fmt_time(s)},{fmt_time(e)},Default,{w.text}\n")

    with open(ass_path, "w") as f:
        f.writelines(lines)


def cut_clip_with_captions(source_path: str, clip: Clip, words: list[Word], job_id: str, idx: int) -> str:
    """Cut the clip, reframe to 9:16 (center crop), and burn in captions."""
    clip_id = f"{job_id}_{idx}"
    raw_cut = os.path.join(WORK_DIR, f"{clip_id}_raw.mp4")
    ass_path = os.path.join(WORK_DIR, f"{clip_id}.ass")
    final_path = os.path.join(OUTPUT_DIR, f"{clip_id}.mp4")

    duration = clip.end - clip.start

    # 1. Cut the segment
    subprocess.run([
        "ffmpeg", "-y", "-ss", str(clip.start), "-i", source_path,
        "-t", str(duration), "-c:v", "libx264", "-c:a", "aac",
        raw_cut,
    ], check=True, capture_output=True)

    # 2. Build captions for this window
    clip_words = _words_in_range(words, clip.start, clip.end)
    _build_ass_subtitles(clip_words, clip.start, ass_path)

    # 3. Center-crop to 9:16 and burn captions in one pass
    vf = (
        "crop=ih*9/16:ih,"
        "scale=1080:1920,"
        f"ass={ass_path}"
    )
    subprocess.run([
        "ffmpeg", "-y", "-i", raw_cut,
        "-vf", vf,
        "-c:v", "libx264", "-c:a", "aac",
        final_path,
    ], check=True, capture_output=True)

    return final_path


def run_pipeline(url: str, api_key: str, max_clips: int, progress_cb=None) -> list[Clip]:
    """Run the full pipeline and return a list of finished Clip objects."""
    def report(msg):
        if progress_cb:
            progress_cb(msg)

    job_id = uuid.uuid4().hex[:8]

    report("Downloading video…")
    source_path = download_video(url, job_id)

    report("Transcribing audio (this can take a few minutes)…")
    words = transcribe(source_path)

    report("Finding the best moments…")
    clips = find_highlights(words, api_key, max_clips=max_clips)

    report(f"Cutting {len(clips)} clip(s) and adding captions…")
    for i, clip in enumerate(clips):
        clip.path = cut_clip_with_captions(source_path, clip, words, job_id, i)
        report(f"Finished clip {i+1}/{len(clips)}: {clip.title}")

    return clips
